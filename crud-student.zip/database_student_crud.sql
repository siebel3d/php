create database student_crud;

drop database student_crud;

use student_crud;